window.onload = () => {
  document.body.classList.add('fade-in');

  let slideIndex = 0;
  const slides = document.querySelectorAll('.slide');

  function showSlides() {
    slides.forEach(slide => slide.classList.remove('active'));
    slideIndex = (slideIndex + 1) % slides.length;
    slides[slideIndex].classList.add('active');
  }

  if (slides.length > 0) {
    slides[0].classList.add('active');
    setInterval(showSlides, 3000);
  }
};